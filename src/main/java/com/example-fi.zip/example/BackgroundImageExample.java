package com.example;

import com.example.DownloadManager;

import javax.swing.*;
import java.util.Timer;
import java.util.TimerTask;

public class BackgroundImageExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private static void createAndShowGUI() {
        // 创建 JFrame
        JFrame frame = new JFrame("Background Image Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        // 设置背景图
        ImageIcon backgroundImage = new ImageIcon("background.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, 800, 600);

        // 将背景图添加到 content pane
        frame.getContentPane().add(backgroundLabel);

        // 使窗口居中显示
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        frame.setResizable(false);
        frame.setVisible(true);

        // 等待3秒后关闭窗口并启动 DownloadManager 类中的 start 函数
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                frame.dispose();
                DownloadManager.start();
                timer.cancel(); // 关闭定时器
            }
        }, 1500);
    }
}
